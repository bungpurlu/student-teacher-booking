// firebaseConfig.js

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCMkoaXxuhVd-67E344Fe9mVCdXY6Xb4Bw",
  authDomain: "student-booking-app-ceee2.firebaseapp.com",
  projectId: "student-booking-app-ceee2",
  storageBucket: "student-booking-app-ceee2.appspot.com", // ✅ Fixed this line
  messagingSenderId: "862119040000",
  appId: "1:862119040000:web:8c1173ecfad597f542f4e5"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

